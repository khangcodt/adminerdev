function
f(){return/ .* /;throw/ .* /;}var
re=/ [/] /;var
nan=1/
/.*//2;