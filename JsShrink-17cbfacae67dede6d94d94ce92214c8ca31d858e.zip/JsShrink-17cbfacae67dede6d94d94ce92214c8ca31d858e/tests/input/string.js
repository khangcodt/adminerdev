var s = ' double ' + ' space ';
